import { createRequire } from 'node:module'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { writeFile } from 'node:fs/promises'
const here = dirname(fileURLToPath(import.meta.url))
const repo = "/Users/shuaimeng/github_web/maple-design-mobile"
const require = createRequire(resolve(repo, 'packages/maple-cli/package.json'))
const { build } = require('vite')
const vue = require('@vitejs/plugin-vue').default
const jsx = require('@vitejs/plugin-vue-jsx').default
const styles = ['input','textarea','input-number','verification-code','switch','checkbox','radio','slider','rate','select','auto-complete','cascader','date','date-range','time','time-range','upload','form']
const imports = styles.map(name => `import ${JSON.stringify(resolve(repo, 'packages/maple-ui/src', name, 'style/index.ts'))}`).join('\n')
await writeFile(resolve(here,'main.js'), `${imports}\nimport { createApp, h, reactive } from 'vue'\nimport * as UI from ${JSON.stringify(resolve(repo,'packages/maple-ui/src/index.ts'))}\nimport {fieldPresentationProp} from ${JSON.stringify(resolve(repo,'packages/maple-ui/src/_components/field-presentation/context.ts'))}\n` + await (await import('node:fs/promises')).readFile(resolve(here,'app.js'),'utf8'))
await writeFile(resolve(here,'index.html'), '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Maple presentation browser acceptance fixture</title><div id="app"></div><script type="module" src="./main.js"></script></html>')
await build({ root: here, base: './', configFile: false, plugins: [vue(),jsx()], resolve: { alias: { vue: require.resolve('vue/dist/vue.runtime.esm-bundler.js') }, dedupe:['vue'] }, build: { outDir:resolve(here,'site'), emptyOutDir:true, minify:true } })
