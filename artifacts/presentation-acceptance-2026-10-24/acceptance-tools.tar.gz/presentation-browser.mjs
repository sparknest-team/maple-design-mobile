import assert from 'node:assert/strict'
import {createServer} from 'node:http'
import {createRequire} from 'node:module'
import {cp,mkdir,mkdtemp,readFile,rm,writeFile} from 'node:fs/promises'
import {resolve,dirname,extname,sep} from 'node:path'
import {fileURLToPath} from 'node:url'
import {tmpdir} from 'node:os'
import {copyProductionSnapshot} from '../../../design-ui/browser/snapshot.mjs'
import {componentPages,mobileComponent,mobileSection,sourceFingerprint,productionFingerprint} from '../../../design-ui/browser/inventory.mjs'
const evidence=dirname(fileURLToPath(import.meta.url)),repo=resolve(evidence,'../..')
const {chromium,devices}=createRequire(resolve(repo,'package.json'))('playwright')
const initialFingerprint={source:sourceFingerprint(repo,'maple'),production:productionFingerprint(repo,'maple')}
const results=[],issues=[],errors=[],selectionMetrics=new Map()
const directory=await mkdtemp(resolve(tmpdir(),'maple-popup-acceptance-'))
if(!process.env.PRESENTATION_ONLY)await copyProductionSnapshot(resolve(repo,'packages/maple-ui/site'),directory)
await copyProductionSnapshot(resolve(evidence,'fixture/site'),resolve(directory,'fixture'))
await mkdir(resolve(evidence,'screenshots'),{recursive:true})
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.wasm':'application/wasm','.woff2':'font/woff2'}
const server=createServer(async(req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=resolve(directory,'.'+(pathname.endsWith('/')?pathname+'index.html':pathname));if(!file.startsWith(directory+sep)){res.writeHead(403).end();return}const body=await readFile(file);res.writeHead(200,{'content-type':types[extname(file)]??'application/octet-stream'}).end(body)}catch{res.writeHead(404).end()}})
await new Promise((done,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',done)})
const origin='http://127.0.0.1:'+server.address().port,browser=await chromium.launch()
const visible=locator=>locator.filter({visible:true})
async function poll(read,accept,message){let value;const until=Date.now()+5000;do{value=await read();if(accept(value))return value;await new Promise(done=>setTimeout(done,25))}while(Date.now()<until);assert.fail(message+'; last='+JSON.stringify(value))}
const panel=page=>visible(page.locator('.mp-field-presentation__panel')).last()
async function assertSurfaceStyles(surface){
 await poll(()=>surface.evaluate(node=>{const box=node.getBoundingClientRect();return {top:box.top,bottom:box.bottom,height:innerHeight,animations:node.getAnimations({subtree:true}).filter(a=>a.playState==='running'&&a.effect?.getComputedTiming().iterations!==Infinity).length}}),box=>box.top>=-1&&box.bottom<=box.height+1&&box.animations===0,'popup animation settles inside viewport')
 for(const name of ['panel','toolbar','close','footer']){const item=name==='panel'?surface:surface.locator('.mp-field-presentation__'+name);assert.match(await item.evaluate(node=>getComputedStyle(node).display),/^(flex|inline-flex)$/,'production '+name+' styling is present')}
}
const confirm=surface=>surface.locator('footer').getByRole('button',{name:/^(确认|确定|Confirm)$/})
async function closePanel(page){const p=panel(page);await p.locator('.mp-field-presentation__close').click();await p.waitFor({state:'hidden'})}
async function edit(page,scope,name,isPopup,actualDemo=false){
 const live=()=>visible(page.locator('.mp-date-panel,.mp-time-panel,[role=dialog]')).last()
 if(['Input','InputPassword','Textarea','VerificationCode'].includes(name)){
  const input=scope.locator(name==='Textarea'?'textarea':'input:not([type=file])').first();const next=name==='VerificationCode'?'9':actualDemo&&(await input.inputValue())==='changed'?'inline changed':'changed';await input.fill(next)
 }else if(name==='InputNumber'){
  await scope.locator('input').first().fill('5');await scope.locator('input').first().blur()
 }else if(['Switch','Checkbox','Radio'].includes(name)){
  await (name==='Switch'?scope.getByRole('switch').first():scope.locator(name==='Radio'?'.mp-radio':'.mp-checkbox').first()).click()
 }else if(['CheckboxGroup','RadioGroup'].includes(name)){
  await scope.locator(name==='CheckboxGroup'?'.mp-checkbox':'.mp-radio').nth(1).click()
 }else if(['Slider','Rate'].includes(name)){
  await scope.getByRole('slider').first().press('ArrowRight')
 }else if(['Select','AutoComplete'].includes(name)){
  if(name==='AutoComplete')await scope.locator('input').first().fill(actualDemo?'设':'Be')
  else if(!isPopup)await scope.getByRole('combobox').first().click()
  const options=visible((isPopup?scope:page).getByRole('option'))
  const option=actualDemo?visible((isPopup?scope:page).locator('[role=option]:not([aria-disabled=true]):not([aria-selected=true])')).last():options.filter({hasText:/^Beta$/}).first()
  await option.click()
 }else if(name==='Cascader'){
  if(!isPopup)await scope.getByRole('combobox').first().click()
  if(actualDemo){if(isPopup)await scope.locator('.mp-cascader-editor-panel__step').first().click();await visible((isPopup?scope:page).getByText(isPopup?'华北':'华东',{exact:true})).last().click();await visible((isPopup?scope:page).getByText(isPopup?'北京':'上海',{exact:true})).last().click()}
  else await visible(page.getByText('Beta',{exact:true})).last().click()
 }else if(['Date','DateRange'].includes(name)){
  if(!isPopup)await scope.locator('.mp-date__input-trigger').first().click()
  const calendar=isPopup?scope.locator('.mp-day-picker').first():visible(page.locator('.mp-date-field-panel')).last().locator('.mp-day-picker').first()
  const day=name==='Date'?(actualDemo&&!isPopup?'22':'21'):'25';await calendar.getByText(day,{exact:true}).click()
  if(name==='DateRange'){await (isPopup?scope:visible(page.locator('.mp-date-field-panel')).last()).locator('.mp-date-range-picker__summary').nth(1).click();await calendar.getByText('26',{exact:true}).click()}
  if(!isPopup){const action=visible(page.getByRole('button',{name:/^(确认|确定|Confirm)$/}));if(await action.count())await action.last().click()}
 }else if(['Time','TimeRange'].includes(name)){
  if(!isPopup)await scope.locator('input').first().click()
  const picker=visible((isPopup?scope:page).locator('.mp-time-picker,.mp-time-range-picker')).last()
  const column=picker.getByRole('listbox').first()
  const hour=actualDemo&&!isPopup?'11':'10';await column.getByText(hour,{exact:true}).click();await poll(()=>column.locator('[aria-selected=true]').innerText(),value=>value.trim().startsWith(hour),'hour wheel selects '+hour);await poll(()=>column.evaluate(node=>node.getAnimations({subtree:true}).filter(a=>a.playState==='running').length),count=>count===0,'time wheel animation settles')
  if(!isPopup){const action=visible(page.getByRole('button',{name:/^(确认|确定|Confirm)$/}));if(await action.count())await action.last().click()}
 }else if(name==='Upload'){
  const filename=actualDemo&&!isPopup?'presentation-inline-qa.txt':'presentation-qa.txt';await scope.locator('input[type=file]').first().setInputFiles({name:filename,mimeType:'text/plain',buffer:Buffer.from('local acceptance fixture')})
  await poll(()=>scope.innerText(),value=>value.includes(filename),'upload draft displays file')
 }else throw new Error('Missing action for '+name)
}
async function fixtureCase(page,name,mode,snapshot){
 await page.getByLabel('Component',{exact:true}).selectOption(name)
 await page.getByLabel('Mode',{exact:true}).selectOption(mode)
 await page.locator('#reset').click()
 const subject=page.locator('#subject'),before=await page.locator('#model').innerText()
 const popup=['popup','form-popup','item-popup','field-popup'].includes(mode)||(['default','form-default','item-default'].includes(mode)&&['Select','AutoComplete','Cascader','Date','DateRange','Time','TimeRange'].includes(name))
 assert.equal(await subject.locator('.mp-field-presentation__reference').count(),popup?1:0,name+' '+mode+' reference state')
 if(popup){
  await subject.locator('.mp-field-presentation__reference').click();let p=panel(page);await p.waitFor({state:'visible'});await assertSurfaceStyles(p)
  assert.equal(await confirm(p).count(),1,'only one outer confirmation boundary')
  if(['Select','AutoComplete'].includes(name)){
   const input=p.locator('input').first(),row=p.locator('[role=option]').first(),inputBox=await input.boundingBox(),rowBox=await row.boundingBox()
   assert.ok(rowBox.y>=inputBox.y+inputBox.height-1,'candidate list is below the search input')
   const key=page.viewportSize().width+'-'+await page.getByLabel('Theme',{exact:true}).inputValue()+'-'+mode
   const metrics=await row.evaluate(node=>({height:node.getBoundingClientRect().height,font:getComputedStyle(node).fontSize,padding:getComputedStyle(node).padding}))
   if(name==='Select')selectionMetrics.set(key,metrics)
   else assert.deepEqual(metrics,selectionMetrics.get(key),'AutoComplete candidates use the standard Select row geometry and typography')
  }

  const box=await p.boundingBox();assert.ok(box.x>=-1&&box.x+box.width<=page.viewportSize().width+1,'popup remains within viewport')
  await edit(page,p,name,true);assert.equal(await page.locator('#model').innerText(),before,'draft cannot update committed model')
  if(snapshot)await page.screenshot({path:resolve(evidence,'screenshots',name+'-'+snapshot+'-popup.png')})
  await closePanel(page);assert.equal(await page.locator('#model').innerText(),before,'cancel discards draft')
  await subject.locator('.mp-field-presentation__reference').click();p=panel(page);await p.waitFor({state:'visible'});await assertSurfaceStyles(p);await edit(page,p,name,true);await confirm(p).click();await p.waitFor({state:'hidden'})
 }else{
  await edit(page,subject,name,false)
  assert.equal(await visible(page.locator('.mp-field-presentation__panel')).count(),0,'explicit inline never opens field popup')
 }
 await poll(()=>page.locator('#model').innerText(),value=>value!==before,name+' '+mode+' updates actual committed model')
 const value=JSON.parse(await page.locator('#model').innerText())
 if(['Input','InputPassword','Textarea'].includes(name))assert.equal(value,'changed')
 else if(name==='InputNumber')assert.equal(value,5)
 else if(name==='VerificationCode')assert.notEqual(value,'1234')
 else if(['Switch','Checkbox','Radio'].includes(name))assert.equal(value,true)
 else if(name==='CheckboxGroup')assert.deepEqual(value,['a','b'])
 else if(['RadioGroup','Select','Cascader'].includes(name))assert.equal(value,'b')
 else if(name==='AutoComplete')assert.equal(value,'Beta')
 else if(['Slider','Rate'].includes(name))assert.ok(value>(name==='Slider'?20:2))
 else if(name==='Date')assert.equal(value,'2026-10-21')
 else if(name==='DateRange')assert.deepEqual(value,['2026-10-25','2026-10-26'])
 else if(name==='Time')assert.equal(value,'10:30')
 else if(name==='TimeRange')assert.deepEqual(value,['10:30','18:00'])
 else if(name==='Upload')assert.equal(value[0].name,'presentation-qa.txt')
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),page.viewportSize().width,'fixture does not overflow')
 return {before,value}
}
async function chooseDocsTheme(page,surface,theme){
 const label=theme==='dark'?'默认暗色':'默认亮色'
 if(surface==='mobile'){await page.locator('.theme-button').click();await page.locator('.mobile-theme-cell').filter({hasText:label}).click();await page.waitForFunction(value=>localStorage.getItem('MAPLE_V3_THEME_DEMO')===value,theme==='dark'?'darkTheme':'lightTheme')}
 else{const menu=page.locator('.maple-site-header__theme');await menu.hover();await menu.locator('.mp-cell').filter({hasText:label}).click();await page.mouse.move(1,1);await page.waitForFunction(value=>localStorage.getItem('MAPLE_V3_THEME')===value,theme==='dark'?'darkTheme':'lightTheme')}
}
async function demoCase(page,demo,name){
 const form=demo.locator('.mp-form').first(),model=demo.locator('.form-model-output'),before=await model.innerText()
 const count=await form.locator('.mp-form-item').count()
 assert.ok(count>0);assert.equal(await form.locator('.mp-field-presentation__reference').count(),count,'each inherited field defaults to popup')
 await form.locator('.mp-field-presentation__reference').first().click();let p=panel(page);await p.waitFor({state:'visible'});await assertSurfaceStyles(p);await edit(page,p,name,true,true);assert.equal(await model.innerText(),before);await closePanel(page);assert.equal(await model.innerText(),before)
 await form.locator('.mp-field-presentation__reference').first().click();p=panel(page);await p.waitFor({state:'visible'});await assertSurfaceStyles(p);await edit(page,p,name,true,true);await confirm(p).click();await p.waitFor({state:'hidden'});await poll(()=>model.innerText(),value=>value!==before,'demo confirms model')
 await demo.locator('.mp-field-presentation__reference').first().click();p=panel(page);await p.waitFor({state:'visible'});await assertSurfaceStyles(p);await visible(page.getByRole('option',{name:'inline',exact:true})).last().click();await confirm(p).click();await p.waitFor({state:'hidden'})
 await poll(()=>form.locator('.mp-field-presentation__reference').count(),value=>value===0,'explicit inline inherited by all demo fields')
 for(const field of await form.locator('.mp-form-item').all())assert.equal(await field.getAttribute('data-presentation'),null,'inline form item omits popup marker')
 const inlineBefore=await model.innerText();await edit(page,form.locator('.mp-form-item').first(),name,false,true);await poll(()=>model.innerText(),value=>value!==inlineBefore,'demo inline editing updates model directly')
 return {fields:count,model:await model.innerText()}
}
async function record(page,details,fn){
 const before=errors.length
 try{const result=await fn();assert.deepEqual(errors.slice(before),[],'no browser script or local asset errors');results.push({...details,passed:true,result});console.log('PASS '+JSON.stringify(details))}
 catch(error){const filename=[details.surface,details.theme,details.component??details.demo,details.mode??'demo'].join('-');await page.screenshot({path:resolve(evidence,'screenshots',filename+'-failure.png')}).catch(()=>{});const diagnostic=await page.locator('body').innerText().catch(()=>'');await writeFile(resolve(evidence,filename+'-failure.json'),JSON.stringify({details,error:String(error),diagnostic,errors:errors.slice(before)},null,2));results.push({...details,passed:false,error:String(error)});console.log('FAIL '+JSON.stringify(details)+' '+error);issues.push(String(error));await page.goto(origin+'/fixture/index.html').catch(()=>{});await page.getByLabel('Theme',{exact:true}).selectOption(details.theme).catch(()=>{})}
}
try{
 const formPage=componentPages(repo,'maple').find(item=>item.component==='form')
 const demos=[['field-components.vue','Input'],['field-choice.vue','Switch'],['field-rating.vue','Slider'],['field-date.vue','Date'],['field-time.vue','Time'],['field-selection.vue','Select'],['field-tree.vue','Cascader'],['field-upload.vue','Upload']]
 for(const surface of ['desktop','mobile'])for(const theme of ['light','dark']){
  const context=await browser.newContext({...(surface==='mobile'?devices['iPhone 13']:{}),viewport:{width:surface==='mobile'?375:1280,height:900},hasTouch:surface==='mobile'})
  await context.route('https://hm.baidu.com/**',route=>route.fulfill({contentType:'text/javascript',body:''}))
  const page=await context.newPage();page.setDefaultTimeout(5000)
  page.on('pageerror',error=>errors.push(String(error)))
  page.on('response',response=>{if(response.url().startsWith(origin)&&response.status()>=400)errors.push(response.status()+' '+response.url())})
  await page.goto(origin+'/fixture/index.html');await page.getByLabel('Theme',{exact:true}).selectOption(theme)
  const definitions=await page.evaluate(()=>window.fixtureDefinitions),inventory=await page.evaluate(()=>window.presentationInventory)
  assert.deepEqual(inventory,[...definitions.map(item=>item.name),'Form','FormItem'].sort(),'all public components sharing field presentation are covered')
  for(const {name} of definitions)for(const mode of ['default','inline','popup']){
   if(process.env.PRESENTATION_DEMOS_ONLY)continue
   if(process.env.PRESENTATION_ONLY&&!process.env.PRESENTATION_ONLY.split(',').includes(name))continue
   await record(page,{surface,theme,component:name,mode},()=>fixtureCase(page,name,mode,mode==='default'?surface+'-'+theme:undefined))
  }
  if(!process.env.PRESENTATION_ONLY&&!process.env.PRESENTATION_DEMOS_ONLY)for(const mode of ['form-default','form-inline','form-popup','item-default','item-inline','item-popup','field-inline','field-popup'])await record(page,{surface,theme,component:'Input',mode},()=>fixtureCase(page,'Input',mode))
  if(!process.env.PRESENTATION_ONLY)for(const [file,name] of demos){
   const index=formPage.demos.findIndex(item=>item.name===file);assert.ok(index>=0,file+' is documented')
   const route=surface==='mobile'?'/mobile.html#/'+mobileComponent(formPage,formPage.demos[index])+'?language=zh-CN':formPage.route
   await page.goto(origin+route);await chooseDocsTheme(page,surface,theme)
   const demo=surface==='mobile'?page.locator('section[data-demo="'+mobileSection(formPage,formPage.demos[index])+'"]'):page.locator('.loca-doc-preview__example').nth(index)
   await record(page,{surface,theme,demo:file},async()=>{await demo.waitFor({state:'visible'});const result=await demoCase(page,demo,name);await page.screenshot({path:resolve(evidence,'screenshots',[surface,theme,file.replace('.vue',''),'inline'].join('-')+'.png')});return result})
  }
  if(!process.env.PRESENTATION_ONLY&&!process.env.PRESENTATION_DEMOS_ONLY){
   const searchPage=componentPages(repo,'maple').find(item=>item.component==='search'),index=searchPage.demos.findIndex(item=>item.name==='presentation.vue')
   const route=surface==='mobile'?'/mobile.html#/'+mobileComponent(searchPage,searchPage.demos[index])+'?language=zh-CN':searchPage.route
   await page.goto(origin+route);await chooseDocsTheme(page,surface,theme)
   const demo=surface==='mobile'?page.locator('section[data-demo="'+mobileSection(searchPage,searchPage.demos[index])+'"]'):page.locator('.loca-doc-preview__example').nth(index)
   await record(page,{surface,theme,demo:'Search inline/popup'},async()=>{
    const input=demo.locator('.mp-search').first().locator('input.mp-input__inner')
    await input.click();assert.equal(await visible(page.locator('.mp-search__popup')).count(),0)
    await visible(page.getByText('项目 A',{exact:true})).last().click();await poll(()=>demo.innerText(),value=>value.includes('最近操作：项目 A'),'inline history search updates output')
    await demo.locator('.mp-checkbox').first().click();await input.click()
    const popup=visible(page.locator('.mp-search__popup')).last();await popup.waitFor({state:'visible'})
    const editor=popup.locator('input.mp-input__inner').first();await editor.fill('Popup QA');await editor.press('Enter');await popup.waitFor({state:'hidden'})
    assert.equal(await input.inputValue(),'Popup QA');assert.ok((await demo.innerText()).includes('最近操作：Popup QA'))
    return {inline:true,popup:true}
   })
  }
  await context.close()
 }
}finally{
 const finalFingerprint={source:sourceFingerprint(repo,'maple'),production:productionFingerprint(repo,'maple')}
 const stable=JSON.stringify(initialFingerprint)===JSON.stringify(finalFingerprint)
 await writeFile(resolve(evidence,(process.env.PRESENTATION_ONLY||process.env.PRESENTATION_DEMOS_ONLY)?'presentation-diagnostic.json':'presentation-coverage.json'),JSON.stringify({scope:process.env.PRESENTATION_ONLY??'complete',node:process.version,fixture:'production Vite bundle of the exact Maple source, separate from rebuilt documentation',initialFingerprint,finalFingerprint,stable,expected:process.env.PRESENTATION_ONLY?null:308,completed:results.length,passed:results.filter(item=>item.passed).length,failed:results.filter(item=>!item.passed).length,results,errors},null,2))
 await browser.close();server.closeAllConnections();await new Promise(done=>server.close(done));await rm(directory,{recursive:true,force:true})
 assert.ok(stable,'source and production inputs remain stable');assert.equal(issues.length,0,'all presentation acceptance cases pass')
}
