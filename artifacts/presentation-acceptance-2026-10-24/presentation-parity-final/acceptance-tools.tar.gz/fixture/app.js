const choices = [{label:'Alpha',value:'a'},{label:'Beta',value:'b'}]
const fields = [
 ['Input','input','initial',{}], ['InputPassword','input-password','abc123',{}],
 ['Textarea','textarea','initial',{}], ['InputNumber','input-number',2,{}],
 ['VerificationCode','verification-code','1234',{length:4}],
 ['Switch','switch',false,{}], ['Checkbox','checkbox',false,{}],
 ['CheckboxGroup','checkbox-group',['a'],{options:choices}],
 ['Radio','radio',false,{value:true}], ['RadioGroup','radio-group','a',{options:choices}],
 ['Slider','slider',20,{step:10}], ['Rate','rate',2,{}],
 ['Select','select','a',{options:choices,filterable:true}],
 ['AutoComplete','auto-complete','Alpha',{options:['Alpha','Beta']}],
 ['Cascader','cascader','a',{options:choices,filterable:true}],
 ['Date','date','2026-10-19',{valueFormat:'YYYY-MM-DD',panelType:'calendar'}],
 ['DateRange','date-range',['2026-10-19','2026-10-22'],{valueFormat:'YYYY-MM-DD',panelType:'calendar'}],
 ['Time','time','09:30',{format:'HH:mm'}], ['TimeRange','time-range',['09:30','18:00'],{format:'HH:mm'}],
 ['Upload','upload',[],{autoUpload:false}],
]
const inventory = Object.entries(UI).filter(([key,value])=>!key.startsWith('_') && value?.props?.presentation===fieldPresentationProp).map(([name])=>name).sort()
window.presentationInventory = inventory
window.fixtureDefinitions = fields.map(([name,id,initial])=>({name,id,initial}))
const state = reactive({ field:'Input',mode:'default',theme:'light',generation:0 })
const model = reactive({value:'initial'})
function reset(){ model.value=structuredClone(fields.find(item=>item[0]===state.field)[2]); state.generation++ }
function theme(value){ state.theme=value; UI.StyleProvider.setStyleVars(UI.Themes.default[value]); document.documentElement.dataset.theme=value }
function control(label,values,current,change){return h('label',{class:'qa-control'},[label,h('select',{'aria-label':label,value:current,onChange:event=>change(event.target.value)},values.map(value=>h('option',{value},value)))])}
createApp({setup(){return()=>{
 const [name,id,initial,extra]=fields.find(item=>item[0]===state.field)
 const fieldProps={...extra,modelValue:model.value,'onUpdate:modelValue':value=>{model.value=value}}
 if(['inline','field-inline'].includes(state.mode))fieldProps.presentation='inline'
 if(['popup','field-popup'].includes(state.mode))fieldProps.presentation='popup'
 const field=()=>h(UI[name],fieldProps, ['Checkbox','Radio'].includes(name)?()=>name:undefined)
 const item=()=>h(UI.FormItem,{label:'QA '+name,...(['item-inline','item-popup'].includes(state.mode)?{presentation:state.mode.slice(5)}:{})},field)
 let subject
 if(state.mode.startsWith('form-') || state.mode.startsWith('field-') || ['item-inline','item-popup'].includes(state.mode)){
  const formProps={model,...(['form-inline','field-popup'].includes(state.mode)?{presentation:'inline'}:['form-popup','field-inline'].includes(state.mode)?{presentation:'popup'}:{})}
  subject=h(UI.Form,formProps,item)
 }else if(state.mode==='item-default')subject=item()
 else subject=field()
 return h('main',[
  h('h1','Maple presentation acceptance'),
  control('Component',fields.map(item=>item[0]),state.field,value=>{state.field=value;reset()}),
  control('Mode',['default','inline','popup','form-default','form-inline','form-popup','item-default','item-inline','item-popup','field-inline','field-popup'],state.mode,value=>{state.mode=value;reset()}),
  control('Theme',['light','dark'],state.theme,theme),
  h('button',{id:'reset',onClick:reset},'Reset'),
  h('section',{id:'subject',key:state.generation,'data-component':id,'data-mode':state.mode},subject),
  h('output',{id:'model'},JSON.stringify(model.value, (key,value)=>key==='file'?undefined:value)),
  h('pre',{id:'inventory'},JSON.stringify(inventory)),
 ])
}}}).mount('#app')
const style=document.createElement('style');style.textContent=`body{margin:0;padding:16px;box-sizing:border-box;background:#fff;color:#111;font-family:system-ui}html[data-theme=dark] body{background:#111;color:#eee}main{max-width:860px;margin:auto}h1{font-size:18px}.qa-control{display:inline-flex;gap:4px;margin:4px}select{max-width:180px}#subject{padding:18px 8px;margin-top:16px;border:1px solid #888}#model{display:block;white-space:pre-wrap;overflow-wrap:anywhere;margin-top:16px}#inventory{white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px}`;document.head.appendChild(style)
